# Screenshot Checklist

Capture the following screenshots after the server is running successfully and after the 3M manual has been ingested.

## 1. Swagger UI
Open:

```powershell
start http://127.0.0.1:8000/docs
```

Save as: `01_swagger_ui.png`

## 2. Successful ingestion
Run:

```powershell
curl.exe -X POST "http://127.0.0.1:8000/ingest" `
  -F "file=@sample_documents\3m_aasd_supplier_quality_manual_rev6.pdf"
```

Save the terminal output as: `02_ingest_success.png`

## 3. Text query result
Run:

```powershell
$body = @{ question = "What certification does 3M recommend for an Automotive Intent Supplier?" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/query" -Method Post -ContentType "application/json" -Body $body
```

Save as: `03_query_text.png`

## 4. Table-oriented query result
Run:

```powershell
$body = @{ question = "What supplier types and certification recommendations are listed in Table 1?" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/query" -Method Post -ContentType "application/json" -Body $body
```

Save as: `04_query_table.png`

## 5. Policy / process query result
Run:

```powershell
$body = @{ question = "Which changes require written approval before production implementation?" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/query" -Method Post -ContentType "application/json" -Body $body
```

Save as: `05_query_process.png`

## 6. Health endpoint
Run:

```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method Get
```

Save as: `06_health_endpoint.png`

## Cleanup step before screenshots

If you tested other PDFs earlier, clear the local index first so only the 3M manual is in the vector store:

```powershell
taskkill /F /IM python.exe
rmdir /S /Q data\chroma_db
rmdir /S /Q data\uploads
```

Then restart the app, ingest the sample PDF once, and capture the screenshots.
