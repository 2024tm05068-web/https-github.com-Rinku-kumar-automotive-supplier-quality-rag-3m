# Sample Document Notes

This folder contains the public sample PDF used for the project demo.

## Included document

- `3m_aasd_supplier_quality_manual_rev6.pdf`

This is the **3M AASD (Automotive) Supplier Quality Manual, Rev. 6**. It is a strong fit for the project because it includes:

- narrative supplier-quality requirements,
- supplier-type certification guidance in a structured table,
- prototype, PPAP, change-control, and traceability requirements,
- raw-material declaration requirements such as RMIF/HMIF, SoC, GADSL, REACH, and conflict minerals,
- packaging, labeling, barcode, and controlled-shipping expectations.

## Usage note

For the cleanest demo, delete any old local vector index, start the API, and ingest only this sample file before running queries or taking screenshots.
